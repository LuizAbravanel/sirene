#include "driver/gpio.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

// Definindo os pinos para os LEDs
#define RED_LED_PIN   GPIO_NUM_5  // LED vermelho no pino D5
#define BLUE_LED_PIN  GPIO_NUM_4  // LED azul no pino D4

void app_main(void) {
    // Configura os pinos como saídas
    gpio_set_direction(RED_LED_PIN, GPIO_MODE_OUTPUT);
    gpio_set_direction(BLUE_LED_PIN, GPIO_MODE_OUTPUT);

    while (1) {
        // Pisca o LED azul três vezes
        for (int i = 0; i < 3; i++) {
            gpio_set_level(RED_LED_PIN, 0);   // Desliga o LED vermelho
            gpio_set_level(BLUE_LED_PIN, 1);  // Acende o LED azul
            vTaskDelay(200 / portTICK_PERIOD_MS);  // Espera por 500 ms

            gpio_set_level(BLUE_LED_PIN, 0);  // Desliga o LED azul
            vTaskDelay(200 / portTICK_PERIOD_MS);  // Espera por 500 ms
        }

        // Pisca o LED vermelho três vezes
        for (int i = 0; i < 3; i++) {
            gpio_set_level(RED_LED_PIN, 1);  // Acende o LED vermelho
            gpio_set_level(BLUE_LED_PIN, 0); // Desliga o LED azul
            vTaskDelay(200 / portTICK_PERIOD_MS);  // Espera por 500 ms

            gpio_set_level(RED_LED_PIN, 0);   // Desliga o LED vermelho
            vTaskDelay(200 / portTICK_PERIOD_MS);  // Espera por 500 ms
        }
    }
}
